import React, { Component } from "react";
import moment from 'moment';
import _ from 'lodash';
import PropTypes from 'prop-types';
// imported elements
import TestDataGenerator, {RandomSerie} from '../../../generators/TestDataGenerator';
// ant.design
import {Upload, Checkbox, Form, Input, Row, Col, Tabs, Icon, Button, Select, DatePicker, message } from 'antd';
const {Option} = Select;
const {TabPane} = Tabs;
const {WeekPicker, MonthPicker, RangePicker} = DatePicker;

function timeout(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
const filterOutAll = (array) => _.filter(array, e=> e !== 'all');

const filterOnlyDoneFiles = (array) => _.filter(array, e=> e.status === 'done');

const isDateAfter = (date) => moment().isBefore(date);

const periods = {
    day: {
        description: "Dzienne",
        default: moment(),
        label: 'Wybór dnia',
        name: 'date-picker',
        rules: [
            { required: true, message: 'Wybierz wartość', type: 'object' },
        ],
        element: <DatePicker disabledDate={isDateAfter}/>,
        formatter: (value) => ({
            from: value.startOf('day').format(),
            to: value.endOf('day').format(),
        })
    },
    week: {
        description: "Tygodniowe",
        default: moment(),
        label: 'Wybór tygodnia',
        name: 'week-picker',
        rules: [
            { required: true, message: 'Wybierz wartość', type: 'object' },
        ],
        element: <WeekPicker disabledDate={isDateAfter} format="WW. [tydzień] YYYY"/>,
        formatter: (value) => ({
            from: value.startOf('week').format(),
            to: value.endOf('week').format(),
        })
    },
    month: {
        description: "Miesięczne",
        default: moment(),
        label: 'Wybór miesiąca',
        name: 'month-picker',
        rules: [
            { required: true, message: 'Wybierz wartość', type: 'object' },
        ],
        element: <MonthPicker disabledDate={isDateAfter}/>,
        formatter: (value) => ({
            from: value.startOf('month').format(),
            to: value.endOf('month').format(),
        })
    },
    userDefined: {
        description: "Inny zakres",
        default: [moment().subtract(1, 'months'), moment()],
        label: 'Wybór zakresu dni',
        name: 'range-picker',
        rules: [
            { required: true, message: 'Wybierz wartość', type: 'array' },
        ],
        element: <RangePicker disabledDate={isDateAfter}/>,
        formatter: (values) => ({
            from: values[0].startOf('day').format(),
            to: values[0].endOf('day').format(),
        })
    }
}

class PeriodSelect extends Component {
    render() {
        return (<Select placeholder="Rodzaj zakresu danych" {...this.props}>
        {
            Object.keys(periods).map(e=>(
                <Option key={e} value={e}>{periods[e].description}</Option>
            ))
        }
        </Select>);
    }
}

class PossibleDataCheckBox extends Component {
    render() {
        const {possibleData, ...props} = this.props;
        return(
        <Checkbox.Group style={{ width: "100%" }} {...props}>
            <Row>
                <Col span={24}>
                    <Checkbox
                        value="all"
                    >
                        Wybierz wszystkie
                    </Checkbox>
                </Col>
            </Row>
            <Row>
                {possibleData.map(e => (
                    <Col key={e.key} span={8}><Checkbox value={e.key}>{e.description}</Checkbox></Col>
                ))}
            </Row>
        </Checkbox.Group>)
    }
}

class CustomUpload extends Component {
    render() {
        const {onChange, disabled} = this.props;
        return (
            <Upload.Dragger
                // TODO
                accept='.txt,.csv,.xls,.xlsx'
                name="files"
                action='./do.do'
                onChange={onChange}
                disabled={disabled}
            >
                <p className="ant-upload-drag-icon">
                    <Icon type="inbox" />
                </p>
                <p className="ant-upload-text">Kliknij lub przeciągnij plik z danymi</p>
                <p className="ant-upload-hint">Wspiera przesłanie pojedynczego pliku.</p>
            </Upload.Dragger>
        );
    }
}

class LoadDataForm extends Component {
    static propTypes = {
        mode: PropTypes.oneOf(['edit', 'load']).isRequired,
        onClose: PropTypes.func,
        loadData: PropTypes.func,
        updateData: PropTypes.func,
    }

    state = {
        dataSource: "db",
        possibleData: [],
        uploadedFiles: 0,
    }

    onUploadChange = (info) => {
        if (info.file.status === 'done') {
            message.success(`${info.file.name} - Plik został załadowany poprawnie`);
        } else if (info.file.status === 'error') {
            message.error(`${info.file.name} - Nie udało się załadować pliku.`);
        }
        this.setState({
            uploadedFiles: filterOnlyDoneFiles(info.fileList)
        });
    }

    changeDataSource = (source) => {
        this.setState({
            dataSource: source
        })
    }

    // TODO zaslepka na strzal
    loadDataFromApi = async (fields) => {
        await timeout(2000);
        const Generator = {};
        fields.measurements.forEach(e =>{ Generator[e] = () => RandomSerie({})});
        return TestDataGenerator(Generator);
    }

    // TODO: strzał
    handleSubmit = async (e) => {
        e.preventDefault();

        const requiredFields = [];
        const formattedFields = [];
        requiredFields.push('description');
        if(this.state.dataSource === 'db') {
            const currentPeriodValue = this.props.form.getFieldValue('selectPeriod')
            requiredFields.push(periods[currentPeriodValue].name);
            formattedFields.push({
                name: periods[currentPeriodValue].name,
                formatter: periods[currentPeriodValue].formatter
            })
            requiredFields.push('measurements');
            formattedFields.push({
                name: 'measurements',
                formatter: filterOutAll
            })
        }
        else {
            requiredFields.push('dropbox');
            formattedFields.push({
                name: 'dropbox',
                formatter: (value) => filterOnlyDoneFiles(value.fileList)
            });
            requiredFields.push('saveOnDB');
            formattedFields.push({
                name: 'saveOnDB',
                formatter: value => Boolean(value)
            })
        }
        this.props.form.validateFields(requiredFields, {}, async (err, fieldsValue) => {
            if (err) {
                return;
            }
            const statusFieldsValue = {...fieldsValue};
            formattedFields.forEach((e) =>{
                fieldsValue[e.name] = e.formatter(fieldsValue[e.name])
            });
            console.log(fieldsValue, formattedFields, 'hehe');
            if (this.props.mode === 'edit') {

            }
            else {
                const data = await this.loadDataFromApi(fieldsValue);
                this.props.loadData({...statusFieldsValue, data})
            }
            this.props.onClose();
            this.handleReset();
            return;
        })
    }

    // TODO: fetch/mock
    loadPossibleData = async () => {
        await timeout(1000);
        const result = [
            {
                key: "temperature",
                description: "Temperatura"
            },
            {
                key: "co2",
                description: "CO2"
            },
            {
                key: "humidity",
                description: "Wilgotność"
            },
        ];
        this.setState ({
            possibleData: result,
            checkedList: ['all', ...result.map(e=>e.key)]
        });
    }
    
    componentDidMount() {
        this.loadPossibleData();
    }

    normalizeCheckBox = (value, prevValue = []) => {
        if (value.indexOf('all') >= 0 && prevValue.indexOf('all') < 0) {
            return ['all', ...this.state.possibleData.map(e=>e.key)];
        }
        if (value.indexOf('all') < 0 && prevValue.indexOf('all') >= 0) {
            return [];
        }
        const filtered = filterOutAll(value);
        if (filtered.length !== this.state.possibleData.length){
            return filtered;
        } else{
            return ['all', ...this.state.possibleData.map(e=>e.key)];
        }
    }

    handleReset = () => {
        this.props.form.resetFields();
    }

    render() {
        const {
            getFieldDecorator, getFieldValue
          } = this.props.form;
        const initialPeriodValue = "month";
        const currentPeriodValue = getFieldValue('selectPeriod') || initialPeriodValue;
        return(
            <Form
                layout="vertical"
                onSubmit={this.handleSubmit}
                hideRequiredMark={true}
                style={{
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                }}
            >
                <div className="LoadDataDialogInner">
                    <Form.Item
                        label="Nazwa zestawu"
                    >
                        {getFieldDecorator('description', {
                            validateTrigger: ['onChange', 'onBlur'],
                            rules: [{
                                required: true,
                                message: 'Proszę podać nazwę zestawu',
                            },
                            {
                                message: 'Wymagana nazwa o długości od 3 do 30 znaków',
                                whitespace: true,
                                min: 3,
                                max: 30
                            }],
                        })(
                            <Input placeholder="Nazwa zestawu danych" />
                        )}
                    </Form.Item>
                    <Form.Item
                        label="Źródło danych"
                    >
                        <Tabs activeKey={this.state.dataSource} onChange={this.changeDataSource}>
                            <TabPane
                                tab={<span><Icon type="database" />Pobierz z bazy danych</span>}
                                key="db"
                            >
                                <Form.Item
                                    label="Rodzaj zakresu danych"
                                >
                                    {getFieldDecorator('selectPeriod', {
                                        validateTrigger: ['onChange'],
                                        rules: [
                                        { required: true, message: 'Wybierz rodzaj zakresu czasu' },
                                        ],
                                        initialValue: initialPeriodValue
                                    })(
                                        <PeriodSelect />
                                    )}
                                </Form.Item>
                                <Form.Item
                                    label={periods[currentPeriodValue].label}
                                >
                                    {getFieldDecorator(periods[currentPeriodValue].name, {
                                        validateTrigger: ['onChange'],
                                        rules: periods[currentPeriodValue].rules,
                                        initialValue: periods[currentPeriodValue].default,
                                    })(
                                        periods[currentPeriodValue].element
                                    )}
                                </Form.Item>
                                {this.state.possibleData.length > 0 && <Form.Item
                                    label="Pobierane pomiary"
                                >
                                    {getFieldDecorator("measurements", {
                                        initialValue: this.state.checkedList,
                                        normalize: this.normalizeCheckBox,
                                        rules: [
                                            {
                                                validator: (rule, value, callback) =>
                                                    ((filterOutAll(value).length === 0) ?
                                                        callback(rule.message) : callback()),
                                                message: "Potrzebny minimum jeden pomiar do pobrania"
                                            }
                                        ]
                                    })(
                                        <PossibleDataCheckBox possibleData={this.state.possibleData}/>
                                    )}
                                </Form.Item>}
                            </TabPane>
                            <TabPane
                                tab={<span><Icon type="upload" />Wgraj z pliku</span>}
                                key="file"
                            >
                                <Form.Item
                                    label="Wczytaj plik"
                                >
                                    <div className="dropbox">
                                        {getFieldDecorator('dropbox', {
                                            valuePropName: 'fileList',
                                            getValueFromEvent: this.normFile,
                                            rules: [
                                                {
                                                    validator: (rule, value, callback) =>
                                                        ((filterOnlyDoneFiles(value.fileList).length !== 1) ?
                                                            callback(rule.message) : callback()),
                                                    message: "Potrzebny poprawny plik do załadowania"
                                                }
                                            ]
                                            })(
                                            <CustomUpload
                                                onChange={this.onUploadChange}
                                                disabled={this.state.uploadedFiles > 0}
                                            />
                                        )}
                                    </div>
                                </Form.Item>
                                <Form.Item>
                                    {getFieldDecorator('saveOnDB', {
                                        })(
                                        <Checkbox>
                                            Zapisz w bazie danych
                                        </Checkbox>
                                    )}
                                </Form.Item>
                            </TabPane>
                        </Tabs>
                    </Form.Item>
                </div>
                <div className="LoadDataDialogSubmit">
                    <Button
                        onClick={this.handleReset}
                        style={{ marginRight: 16 }}
                    >
                        Zresetuj
                    </Button>
                    <Button
                        type="primary"
                        icon="plus"
                        htmlType="submit"
                        disabled={!(this.state.possibleData.length > 0)}
                    >
                        Dodaj dane
                    </Button>
                </div>
            </Form>
        );
    }
}

const WrappedLoadDataForm = Form.create({ name: 'load_data_form' })(LoadDataForm);

class LoadDataDialog extends Component {
    static propTypes = {
        mode: PropTypes.string,
        onClose: PropTypes.func,
        loadData: PropTypes.func,
        updateData: PropTypes.func,
    }

    render() {
        const {mode, onClose, loadData, updateData} = this.props
        return (
            <div className="LoadDataDialog">
                {mode === 'edit' ? 
                    <WrappedLoadDataForm
                        mode='edit'
                        onClose={onClose}
                        updateData={updateData}
                    />
                    :
                    <WrappedLoadDataForm
                        mode='load'
                        onClose={onClose}
                        loadData={loadData}
                    />
                }
            </div>
        );
    }
}

export default LoadDataDialog;
