import React, { Component } from "react";
// imported elements
// ant.design

class ConfigChart extends Component {
    render() {
        return (
            <div className="ConfigChart">
                <p>TEST</p>
            </div>
        );
    }
}

export default ConfigChart;
