import React from "react";

import ChartSetup from "./Charts/ChartSetup";

const Chart = () => (
  <div style={{ width: "420px" }}>
    <ChartSetup />
  </div>
);

export default Chart;
